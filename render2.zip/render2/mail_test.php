<?php
$to = "your_email@example.com";
$subject = "Test Email";
$message = "This is a test email to check if the mail() function is working.";
$headers = "From: Your Name <your_email@example.com>";

if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully!";
} else {
    echo "Error sending email.";
}
?>