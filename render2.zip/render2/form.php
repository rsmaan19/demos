

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    ob_start(); // Start output buffering

    // Suppress error reporting temporarily
    error_reporting(0);

    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $phone = htmlspecialchars($_POST["phone"]);
    $location = htmlspecialchars($_POST["location"]);
    $service = htmlspecialchars($_POST["service"]);
    $message = htmlspecialchars($_POST["message"]);

    // Email configuration
    $to = "admin@aiworld.host"; // Replace with your email address
    $subject = "Swift Rendering Form Submission";

    // HTML email content with inline styling
    $body = "
     <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; color: #333; }
            .email-container { width: 100%; padding: 20px; background-color: #f9f9f9; }
            .email-content { max-width: 600px; margin: auto; background-color: #ffffff; padding: 20px; border: 1px solid #ddd; }
            h2 { color: #0056b3; }
            .field { font-weight: bold; color: #0056b3; }
            .message { margin-top: 10px; }
        </style>
    
        </head>
    <body>
        <div class='email-container'>
            <div class='email-content'>
                <h2>Message from Swift Rendering</h2>
                <p><span class='field'>Client Name:</span> $name</p>
                <p><span class='field'>Email:</span> $email</p>
                <p><span class='field'>Phone:</span> $phone</p>
                <p><span class='field'>Location:</span> $location</p>
                <p><span class='field'>Service:</span> $service</p>
                <div class='message'>
                    <p><span class='field'>Message:</span></p>
                    <p>$message</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";

    // Set headers for HTML email
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    // Send the email and capture the result
    $isSent = mail($to, $subject, $body, $headers);

    ob_end_clean(); // Clean output buffer

    if ($isSent) {
        echo "success"; // Send "success" message back to AJAX
    } else {
        echo "error"; // Send "error" message back to AJAX
    }

    exit; // Ensure no additional content is sent
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<!--    <meta name="viewport" content="width=device-width, initial-scale=1.0">-->
<!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">-->
    <title>Contact Form</title>
    <style>
        .alert {
            display: none; /* Hide alerts initially */
        }
    </style>
</head>
<body>
<div class="container py-5 px-3 px-md-5"  style="background-image: url('img/form-bg.webp');">
    <div class="px-md-3">
<h2 style="color:white; font-weight:700; margin-bottom: 15px;">SEND US MESSAGE</h2>
    <form id="contactForm">
<div class="row">
    <div class="mb-3 col-12 col-sm-6">
            <input type="text" class="form-control" id="name" name="name" placeholder="Name*" required style="border-radius:0px; padding: 15px 10px 15px 15px;">
        </div>
        <div class="mb-3 col-12 col-sm-6">
            <input type="email" class="form-control" id="email" name="email" placeholder="Email*" required style="border-radius:0px; padding: 15px 10px 15px 15px;">
        </div>
        <div class="mb-3 col-12 col-sm-6">
            <input type="tel" class="form-control" id="phone" name="phone" placeholder="Phone Number*" required style="border-radius:0px; padding: 15px 10px 15px 15px;">
        </div>
            <div class="mb-3 col-12 col-sm-6">
            <input type="text" class="form-control" id="location" name="location" placeholder="Your Location" required style="border-radius:0px; padding: 15px 10px 15px 15px;">
        </div>
        <div class="mb-3 col-12">
            <select class="form-select" id="service" name="service" required style="border-radius:0px; padding: 15px 10px 15px 15px;">
                <option value="" disabled selected>Select Service</option>
                <option value="consultation">Consultation</option>
                <option value="support">Support</option>
                <option value="development">Development</option>
                <option value="design">Design</option>
            </select>
        </div>
        <div class="mb-3 col-12">
            <textarea class="form-control" id="message" name="message" rows="4" placeholder="Message" required style="border-radius:0px; padding: 15px 10px 15px 15px;"></textarea>
        </div>
        <div class="mb-3 col-12">
        <button type="submit" class="btn btn-primary" style="border-radius:0; padding:15px; width:100%;">Submit</button>
    </div>
    </div>
    </form>

    <!-- Success and Error Messages -->
    <div id="successMessage" class="alert alert-success mt-3">Message Sent✅. You'll get contacted shortly</div>
    <div id="errorMessage" class="alert alert-danger mt-3">There was an error sending your message. Please try again later.</div>
    </div>
</div>

<!-- AJAX and Form Handling -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#contactForm').on('submit', function(e) {
            e.preventDefault(); // Prevent default form submission

            $.ajax({
                url: '', // Current file (contact_form.php) will handle the request
                type: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    if (response.trim() === "success") { // Trim any whitespace around response
                        $('#successMessage').show(); // Show success message
                        $('#errorMessage').hide(); // Hide error message if it's visible
                        $('#contactForm')[0].reset(); // Clear the form fields
                    } else {
                        $('#errorMessage').show(); // Show error message
                        $('#successMessage').hide(); // Hide success message if it's visible
                    }
                },
                error: function() {
                    $('#errorMessage').show();
                    $('#successMessage').hide();
                }
            });
        });
    });
</script>

</body>
</html>